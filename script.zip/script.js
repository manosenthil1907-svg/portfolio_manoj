import React, { useState } from "react";

function App() {
  const [formData, setFormData] = useState({
    name: "",
    date: "",
    time: "",
    guests: 1,
    occasion: "Birthday"
  });

  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    let newErrors = {};

    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (!formData.date) newErrors.date = "Date is required";
    if (!formData.time) newErrors.time = "Time is required";

    if (formData.guests < 1 || formData.guests > 10) {
      newErrors.guests = "Guests must be between 1 and 10";
    }

    // Edge case: past date
    if (formData.date) {
      const selected = new Date(formData.date);
      const today = new Date();
      today.setHours(0,0,0,0);
      if (selected < today) {
        newErrors.date = "Cannot select past date";
      }
    }

    return newErrors;
  };

  const handleChange = (e) => {
    const value =
      e.target.name === "guests" ? parseInt(e.target.value) : e.target.value;

    setFormData({
      ...formData,
      [e.target.name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();

    if (Object.keys(validationErrors).length === 0) {
      setErrors({});
      setSubmitted(true);
    } else {
      setErrors(validationErrors);
      setSubmitted(false);
    }
  };

  return (
    <main style={styles.container}>
      <header>
        <h1 style={styles.title}>Little Lemon 🍋</h1>
        <p style={styles.subtitle}>Reserve your table</p>
      </header>

      <form onSubmit={handleSubmit} style={styles.form} aria-label="Booking Form">

        <label htmlFor="name">Name</label>
        <input
          id="name"
          name="name"
          type="text"
          value={formData.name}
          onChange={handleChange}
          style={styles.input}
        />
        {errors.name && <span style={styles.error}>{errors.name}</span>}

        <label htmlFor="date">Date</label>
        <input
          id="date"
          name="date"
          type="date"
          value={formData.date}
          onChange={handleChange}
          style={styles.input}
        />
        {errors.date && <span style={styles.error}>{errors.date}</span>}

        <label htmlFor="time">Time</label>
        <input
          id="time"
          name="time"
          type="time"
          value={formData.time}
          onChange={handleChange}
          style={styles.input}
        />
        {errors.time && <span style={styles.error}>{errors.time}</span>}

        <label htmlFor="guests">Guests</label>
        <input
          id="guests"
          name="guests"
          type="number"
          min="1"
          max="10"
          value={formData.guests}
          onChange={handleChange}
          style={styles.input}
        />
        {errors.guests && <span style={styles.error}>{errors.guests}</span>}

        <label htmlFor="occasion">Occasion</label>
        <select
          id="occasion"
          name="occasion"
          value={formData.occasion}
          onChange={handleChange}
          style={styles.input}
        >
          <option>Birthday</option>
          <option>Anniversary</option>
        </select>

        <button type="submit" style={styles.button}>
          Book Table
        </button>

        {submitted && (
          <p style={styles.success}>✅ Booking Successful!</p>
        )}
      </form>
    </main>
  );
}

const styles = {
  container: {
    fontFamily: "Arial",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "20px"
  },
  title: {
    color: "green"
  },
  subtitle: {
    marginBottom: "20px"
  },
  form: {
    display: "grid",
    gap: "10px",
    width: "300px"
  },
  input: {
    padding: "8px",
    fontSize: "14px"
  },
  button: {
    padding: "10px",
    backgroundColor: "green",
    color: "white",
    border: "none",
    cursor: "pointer"
  },
  error: {
    color: "red",
    fontSize: "12px"
  },
  success: {
    color: "green",
    fontWeight: "bold"
  }
};

export default App;